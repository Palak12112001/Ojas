$(document).ready(function () {
    // Toggle sidebar menu
    $('.btn-menu').on('click', function () {
        $('#sidebar').toggleClass('active'); // Toggle sidebar active class
        $('.btn-menu').toggleClass('active'); // Toggle button active class
    });
     

        });

